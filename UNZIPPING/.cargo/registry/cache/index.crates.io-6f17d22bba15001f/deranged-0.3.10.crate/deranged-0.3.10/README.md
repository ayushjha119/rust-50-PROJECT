# Deranged

This crate is a proof-of-concept implementation of ranged integers.
